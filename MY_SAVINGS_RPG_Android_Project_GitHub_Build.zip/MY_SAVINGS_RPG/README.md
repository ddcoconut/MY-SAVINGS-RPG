# MY SAVINGS RPG — Android project

Aplicación Android nativa en Kotlin, con interfaz oscura morada y almacenamiento local persistente mediante SharedPreferences.

## Incluye
- Panel de control y nivel/XP.
- Metas editables (Soundcore Boom 2 Plus e iScooter iX7 Pro).
- Registro de semanas: suma $450 de ingreso, $250 al ahorro y $200 al saldo disponible.
- Registro de gastos e ingresos extra.
- Historial de movimientos con edición y eliminación.
- Estadísticas y gráfica de ahorro.
- Calendario de semanas registradas.
- Datos guardados localmente en el dispositivo.

## Abrir y generar APK
1. Instala Android Studio en una computadora.
2. Descomprime este proyecto.
3. En Android Studio, selecciona **Open** y elige la carpeta `MY_SAVINGS_RPG`.
4. Espera a que Gradle sincronice y descargue Android Gradle Plugin 8.7.3.
5. Conecta un Android o usa un emulador y pulsa Run.
6. Para generar el APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. Android Studio mostrará la ubicación del APK generado (normalmente `app/build/outputs/apk/debug/app-debug.apk`).

## Datos y límites
- Los datos se guardan en el almacenamiento privado de la app en ese teléfono.
- Desinstalar la app puede borrar esos datos; exportación/copia de seguridad aún no está implementada.
- No hay cuenta, nube ni sincronización.
- La app no se conecta a bancos ni procesa pagos.
- La primera versión usa importes de referencia: $2,200 para la bocina y $9,500 para el scooter. Puedes editarlos dentro de la app.
- El proyecto fuente no incluye un APK compilado. Para compilarlo se necesita Android SDK y Gradle, normalmente instalados mediante Android Studio.
