# Producto
Nombre: MY SAVINGS RPG
Paquete: com.mysavingsrpg.app
Plataforma: Android nativo
Tema: dark purple
Persistencia: SharedPreferences + JSON local
Moneda: MXN
Ingreso semanal inicial: $450
Ahorro semanal planificado: $250
Saldo semanal para gastos: $200
Metas iniciales: Soundcore Boom 2 Plus ($2,200), iScooter iX7 Pro ($9,500)
