package com.mysavingsrpg.app

import android.app.*
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.InputType
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

data class Movement(val id: Long, var title: String, val kind: String, var amount: Double, val date: Long)
data class Goal(val id: String, var title: String, var target: Double, var saved: Double)

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("savings_rpg_data", MODE_PRIVATE) }
    private val bg = Color.rgb(17, 16, 29)
    private val panel = Color.rgb(31, 29, 51)
    private val panel2 = Color.rgb(42, 39, 67)
    private val purple = Color.rgb(167, 139, 250)
    private val green = Color.rgb(52, 211, 153)
    private val white = Color.WHITE
    private val muted = Color.rgb(177, 172, 201)
    private lateinit var content: LinearLayout
    private lateinit var nav: LinearLayout
    private var tab = "Inicio"
    private var saved = 0.0
    private var wallet = 0.0
    private var income = 0.0
    private var expenses = 0.0
    private var weeks = 0
    private var movements = mutableListOf<Movement>()
    private var goals = mutableListOf<Goal>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        loadData()
        buildShell()
        showTab()
    }

    private fun money(v: Double) = NumberFormat.getCurrencyInstance(Locale("es", "MX")).format(v)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun loadData() {
        saved = prefs.getFloat("saved", 0f).toDouble()
        wallet = prefs.getFloat("wallet", 0f).toDouble()
        income = prefs.getFloat("income", 0f).toDouble()
        expenses = prefs.getFloat("expenses", 0f).toDouble()
        weeks = prefs.getInt("weeks", 0)
        val arr = JSONArray(prefs.getString("movements", "[]"))
        movements.clear()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            movements.add(Movement(o.getLong("id"), o.getString("title"), o.getString("kind"), o.getDouble("amount"), o.getLong("date")))
        }
        val g = JSONArray(prefs.getString("goals", "[]"))
        goals.clear()
        if (g.length() == 0) {
            goals.add(Goal("speaker", "Soundcore Boom 2 Plus", 2200.0, 0.0))
            goals.add(Goal("scooter", "iScooter iX7 Pro", 9500.0, 0.0))
        } else {
            for (i in 0 until g.length()) {
                val o = g.getJSONObject(i)
                goals.add(Goal(o.getString("id"), o.getString("title"), o.getDouble("target"), o.getDouble("saved")))
            }
        }
        syncGoals()
    }

    private fun saveData() {
        val a = JSONArray()
        movements.forEach { m ->
            a.put(JSONObject().put("id", m.id).put("title", m.title).put("kind", m.kind).put("amount", m.amount).put("date", m.date))
        }
        val g = JSONArray()
        goals.forEach { x ->
            g.put(JSONObject().put("id", x.id).put("title", x.title).put("target", x.target).put("saved", x.saved))
        }
        prefs.edit().putFloat("saved", saved.toFloat()).putFloat("wallet", wallet.toFloat())
            .putFloat("income", income.toFloat()).putFloat("expenses", expenses.toFloat())
            .putInt("weeks", weeks).putString("movements", a.toString()).putString("goals", g.toString()).apply()
    }

    private fun syncGoals() {
        if (goals.size < 2) return
        goals[0].saved = min(saved, goals[0].target)
        goals[1].saved = min(max(0.0, saved - goals[0].target), goals[1].target)
    }

    private fun buildShell() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(18), dp(20), dp(12)); setBackgroundColor(bg)
        }
        val brand = TextView(this).apply {
            text = "◈  MY SAVINGS RPG"; textSize = 19f; setTextColor(white); setTypeface(null, android.graphics.Typeface.BOLD)
        }
        val tagline = TextView(this).apply { text = "TU DINERO · TUS REGLAS"; textSize = 10f; setTextColor(muted) }
        header.addView(brand); header.addView(tagline)
        root.addView(header)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(12))
        }
        val scroll = ScrollView(this).apply { addView(content) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(panel); setPadding(dp(4), dp(8), dp(4), dp(8)) }
        listOf("Inicio", "Metas", "Movimientos", "Estadísticas", "Calendario").forEach { name ->
            val b = TextView(this).apply {
                text = when(name) { "Estadísticas" -> "📊\nStats"; "Movimientos" -> "↕\nMov."; "Calendario" -> "▦\nDías"; else -> when(name) { "Inicio" -> "⌂\nInicio"; else -> "◎\nMetas" } }
                textSize = 10f; gravity = Gravity.CENTER; setTextColor(if (name == tab) purple else muted)
                setPadding(dp(3), dp(4), dp(3), dp(4))
                setOnClickListener { tab = name; showTab() }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
        setContentView(root)
    }

    private fun showTab() {
        content.removeAllViews()
        when(tab) {
            "Inicio" -> home()
            "Metas" -> goalsPage()
            "Movimientos" -> movementsPage()
            "Estadísticas" -> statsPage()
            "Calendario" -> calendarPage()
        }
        buildNavSelection()
    }

    private fun buildNavSelection() {
        for (i in 0 until nav.childCount) {
            val v = nav.getChildAt(i) as TextView
            val names = listOf("Inicio", "Metas", "Movimientos", "Estadísticas", "Calendario")
            v.setTextColor(if (names[i] == tab) purple else muted)
        }
    }

    private fun title(t: String, sub: String? = null) {
        val tv = TextView(this).apply { text = t; textSize = 23f; setTextColor(white); setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, dp(6), 0, dp(3)) }
        content.addView(tv)
        if (sub != null) content.addView(TextView(this).apply { text = sub; textSize = 12f; setTextColor(muted); setPadding(0, 0, 0, dp(12)) })
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(15), dp(14), dp(15), dp(14))
        setBackgroundColor(panel)
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(10); content.addView(this, lp)
    }

    private fun label(parent: LinearLayout, text: String, size: Float = 13f, color: Int = muted, bold: Boolean = false) {
        parent.addView(TextView(this).apply { this.text = text; textSize = size; setTextColor(color); if (bold) setTypeface(null, android.graphics.Typeface.BOLD) })
    }

    private fun metric(parent: LinearLayout, name: String, value: String, color: Int = white) {
        label(parent, name.uppercase(), 10f, muted, true)
        label(parent, value, 23f, color, true)
    }

    private fun button(parent: LinearLayout, text: String, action: () -> Unit) {
        val b = Button(this).apply {
            this.text = text; textSize = 12f; isAllCaps = false; setTextColor(white)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(91, 66, 145)))
            setOnClickListener { action() }
        }
        parent.addView(b, LinearLayout.LayoutParams(-1, -2))
    }

    private fun progress(parent: LinearLayout, value: Double, target: Double, color: Int = purple) {
        val p = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000; progress = (if (target > 0) (value / target * 1000).toInt() else 0).coerceIn(0,1000)
            progressTintList = android.content.res.ColorStateList.valueOf(color)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(panel2)
        }
        parent.addView(p, LinearLayout.LayoutParams(-1, dp(9)))
    }

    private fun home() {
        title("Panel de control", "Tu aventura financiera empieza aquí.")
        val c = card()
        metric(c, "Capital ahorrado", money(saved), green)
        val level = (saved / 1000).toInt() + 1
        label(c, "NIVEL $level  ·  ${(saved.toInt() % 1000)} / 1000 XP", 11f, purple, true)
        progress(c, saved % 1000, 1000.0)
        val grid = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        c.addView(grid)
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(12), dp(8), 0) }
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(12), 0, 0) }
        grid.addView(left, LinearLayout.LayoutParams(0,-2,1f)); grid.addView(right, LinearLayout.LayoutParams(0,-2,1f))
        metric(left, "Disponible", money(wallet), green); metric(right, "Ingresos", money(income))
        metric(left, "Gastos", money(expenses)); metric(right, "Semanas", weeks.toString())
        val weekly = card()
        label(weekly, "TU PRESUPUESTO SEMANAL", 11f, purple, true)
        label(weekly, "Ingreso $450  ·  Ahorro $250  ·  Disponible $200", 13f, white)
        button(weekly, "＋ Registrar semana (+$450 ingreso / +$250 ahorro)") {
            income += 450; saved += 250; wallet += 200; weeks++
            addMovement("Ingreso semanal", "Ingreso", 450.0)
            addMovement("Ahorro semanal", "Ahorro", 250.0)
            syncGoals(); saveData(); showTab()
            Toast.makeText(this, "¡Semana registrada!", Toast.LENGTH_SHORT).show()
        }
        goals.take(2).forEach { g ->
            val gc = card()
            label(gc, "MISIÓN · ${g.title}", 12f, purple, true)
            label(gc, "${money(g.saved)} / ${money(g.target)}", 19f, white, true)
            progress(gc, g.saved, g.target, if (g.id == "speaker") purple else green)
        }
    }

    private fun goalsPage() {
        title("Mis metas", "Ajusta los precios cuando encuentres una buena oferta.")
        goals.forEach { g ->
            val c = card()
            label(c, if (g.id == "speaker") "MISIÓN 01 · AUDIO" else "MISIÓN 02 · MOVILIDAD", 10f, purple, true)
            label(c, g.title, 17f, white, true)
            label(c, "${money(g.saved)} / ${money(g.target)}", 19f, green, true)
            progress(c, g.saved, g.target, if (g.id == "speaker") purple else green)
            button(c, "Editar meta") { editGoal(g) }
        }
        button(content, "＋ Añadir otra meta") {
            val id = System.currentTimeMillis().toString()
            val g = Goal(id, "Nueva meta", 1000.0, 0.0); goals.add(g); saveData(); showTab(); editGoal(g)
        }
    }

    private fun editGoal(g: Goal) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val name = EditText(this).apply { setText(g.title); hint = "Nombre de la meta" }
        val target = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL; setText(g.target.toString()); hint = "Precio objetivo" }
        box.addView(name); box.addView(target)
        AlertDialog.Builder(this).setTitle("Editar meta").setView(box)
            .setPositiveButton("Guardar") { _, _ ->
                val t = target.text.toString().toDoubleOrNull()
                if (name.text.isNotBlank() && t != null && t > 0) { g.title = name.text.toString(); g.target = t; syncGoals(); saveData(); showTab() }
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun movementsPage() {
        title("Movimientos", "Toca un movimiento para editarlo o eliminarlo.")
        val c = card()
        metric(c, "Dinero disponible", money(wallet), green)
        button(c, "＋ Registrar gasto") { expenseDialog() }
        button(c, "＋ Registrar ingreso extra") { incomeDialog() }
        if (movements.isEmpty()) {
            val empty = card(); label(empty, "Aún no hay movimientos. Registra tu primera semana.", 13f, muted)
        }
        movements.sortedByDescending { it.date }.forEach { m ->
            val row = card()
            label(row, m.title, 14f, white, true)
            label(row, "${m.kind} · ${java.text.DateFormat.getDateInstance().format(java.util.Date(m.date))}", 10f, muted)
            label(row, (if (m.kind == "Gasto") "−" else "+") + money(m.amount), 16f, if (m.kind == "Gasto") Color.rgb(251,146,60) else green, true)
            row.setOnClickListener { movementMenu(m) }
        }
    }

    private fun movementMenu(m: Movement) {
        AlertDialog.Builder(this).setTitle(m.title)
            .setItems(arrayOf("Editar", "Eliminar")) { _, which -> if (which == 0) editMovement(m) else deleteMovement(m) }.show()
    }

    private fun editMovement(m: Movement) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val name = EditText(this).apply { setText(m.title); hint = "Descripción" }
        val amount = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL; setText(m.amount.toString()) }
        box.addView(name); box.addView(amount)
        AlertDialog.Builder(this).setTitle("Editar movimiento").setView(box)
            .setPositiveButton("Guardar") { _, _ ->
                val n = amount.text.toString().toDoubleOrNull()
                if (n != null && n > 0) { m.title = name.text.toString(); m.amount = n; recalcBalances(); saveData(); showTab() }
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun deleteMovement(m: Movement) {
        AlertDialog.Builder(this).setMessage("¿Eliminar este movimiento? Los saldos se recalcularán.")
            .setNegativeButton("Cancelar", null).setPositiveButton("Eliminar") { _, _ ->
                movements.remove(m); recalcBalances(); saveData(); showTab()
            }.show()
    }

    private fun recalcBalances() {
        income = movements.filter { it.kind == "Ingreso" }.sumOf { it.amount }
        expenses = movements.filter { it.kind == "Gasto" }.sumOf { it.amount }
        saved = movements.filter { it.kind == "Ahorro" }.sumOf { it.amount }
        wallet = income - expenses - saved
        weeks = movements.count { it.kind == "Ingreso semanal" || it.title == "Ingreso semanal" }
        syncGoals()
    }

    private fun expenseDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val name = EditText(this).apply { hint = "Ej. comida, transporte" }
        val amount = EditText(this).apply { hint = "Cantidad en MXN"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }
        box.addView(name); box.addView(amount)
        AlertDialog.Builder(this).setTitle("Nuevo gasto").setView(box)
            .setPositiveButton("Guardar") { _, _ ->
                val n = amount.text.toString().toDoubleOrNull()
                if (n != null && n > 0 && n <= wallet) { wallet -= n; expenses += n; addMovement(name.text.toString().ifBlank { "Gasto" }, "Gasto", n); saveData(); showTab() }
                else Toast.makeText(this, "Importe inválido o saldo insuficiente.", Toast.LENGTH_LONG).show()
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun incomeDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val name = EditText(this).apply { hint = "Descripción del ingreso" }
        val amount = EditText(this).apply { hint = "Cantidad en MXN"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }
        box.addView(name); box.addView(amount)
        AlertDialog.Builder(this).setTitle("Ingreso extra").setView(box)
            .setPositiveButton("Guardar") { _, _ ->
                val n = amount.text.toString().toDoubleOrNull()
                if (n != null && n > 0) { wallet += n; income += n; addMovement(name.text.toString().ifBlank { "Ingreso extra" }, "Ingreso", n); saveData(); showTab() }
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun addMovement(title: String, kind: String, amount: Double) {
        movements.add(0, Movement(System.currentTimeMillis(), title, kind, amount, System.currentTimeMillis()))
    }

    private fun statsPage() {
        title("Estadísticas", "Visualiza cómo crece tu capital.")
        val c = card()
        metric(c, "Total ahorrado", money(saved), green)
        label(c, "Ingresos: ${money(income)}", 13f, white)
        label(c, "Gastos: ${money(expenses)}", 13f, white)
        label(c, "Disponible: ${money(wallet)}", 13f, white)
        val graph = card()
        label(graph, "AHORRO POR MOVIMIENTO", 11f, purple, true)
        graph.addView(SavingsChart(this, movements.filter { it.kind == "Ahorro" }.take(12).reversed().map { it.amount.toFloat() }), LinearLayout.LayoutParams(-1, dp(170)))
        val achievements = card()
        label(achievements, "LOGROS", 11f, purple, true)
        val badges = listOf(
            "Primera semana" to (weeks >= 1),
            "Cinco semanas" to (weeks >= 5),
            "Primeros $1,000" to (saved >= 1000),
            "Meta de la bocina" to (goals.firstOrNull()?.let { saved >= it.target } == true)
        )
        badges.forEach { (name, ok) -> label(achievements, (if(ok) "🏆 " else "🔒 ") + name, 13f, if(ok) green else muted) }
    }

    private fun calendarPage() {
        title("Calendario", "Historial de semanas de ahorro.")
        val c = card()
        label(c, "SEMANAS REGISTRADAS: $weeks", 12f, purple, true)
        if (weeks == 0) label(c, "Todavía no has registrado semanas.", 13f, muted)
        else {
            for (i in 1..weeks.coerceAtMost(60)) {
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(7), 0, dp(7)) }
                label(row, "✓  Semana $i", 13f, green, true)
                row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
                label(row, "+$250", 13f, white, true)
                c.addView(row)
            }
        }
        button(c, "Registrar semana") {
            income += 450; saved += 250; wallet += 200; weeks++
            addMovement("Ingreso semanal", "Ingreso", 450.0)
            addMovement("Ahorro semanal", "Ahorro", 250.0)
            syncGoals(); saveData(); showTab()
        }
    }

    class SavingsChart(context: android.content.Context, private val values: List<Float>) : View(context) {
        private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(167,139,250); strokeWidth = 5f; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(52,211,153); style = Paint.Style.FILL }
        private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(70,65,95); strokeWidth = 1f }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val l = 20f; val r = width - 20f; val t = 20f; val b = height - 20f
            for (i in 0..3) { val y = t + (b-t)*i/3; canvas.drawLine(l,y,r,y,grid) }
            if (values.isEmpty()) return
            val maxV = max(250f, values.maxOrNull() ?: 250f)
            val step = if(values.size == 1) 0f else (r-l)/(values.size-1)
            val path = android.graphics.Path()
            values.forEachIndexed { i,v ->
                val x = l + i*step; val y = b - (v/maxV)*(b-t)
                if(i==0) path.moveTo(x,y) else path.lineTo(x,y)
                canvas.drawCircle(x,y,6f,dot)
            }
            canvas.drawPath(path,line)
        }
    }
}
